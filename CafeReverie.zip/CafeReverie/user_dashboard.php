
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('bj.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: black;
        }

        .dashboard {
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 50%;
        }

        h1 {
            font-size: 24px;
        }

        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .button {
            padding: 60px 50px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #45a049;
        }

        .lgbutton {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
            cursor: pointer;
    </style>
</head>
<body>

    <div class="dashboard">
        <?php
        session_start();
        if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
            header("Location: login.html");
            exit;
        }
        echo "<h1>Hello " . htmlspecialchars($_SESSION['username']) . "</h1>";
        ?>
        <a href="index.html" class="lgbutton">Logout</a>
        <div class="buttons-container">
            <a href="products.html" class="button">View <br> Products</a>
            <a href="comment_section.php" class="button">My<br> Reviews</a>
        </div>
        
    </div> 
    
</body>
</html>
