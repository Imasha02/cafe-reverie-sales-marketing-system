<?php
$servername = "localhost";
$username = "imasha"; 
$password = "imasha123";
$dbname = "cafe";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$user = $_POST['username'];
$pass = $_POST['password'];
$role = $_POST['role'];

echo $user;


$stmt = $conn->prepare("INSERT INTO new (username, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $user, $pass, $role);


if ($stmt->execute() === TRUE) {
    echo "New record created successfully"; 
   header("Location: userlogin.html");
   exit();
} else {
    echo "Error: " . $stmt->error;
}


$stmt->close();
$conn->close();
?>

