<?php
// Database connection details
$servername = "localhost";
$username = "imasha";
$password = "imasha123";
$dbname = "cafe";


$conn = mysqli_connect($servername, $username, $password, $dbname);


if (mysqli_connect_errno()) { 
     echo "Failed to connect!";
   exit();
}
// echo "connection success!";

?>

