<?php
$conn = new mysqli("localhost", "imasha", "imasha123", "cafe");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    $sql = "DELETE FROM new WHERE id = ? AND role = 'user'";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        echo "<p class='success'>User deleted successfully.</p>";
    } else {
        echo "<p class='error'>Error deleting user: " . $conn->error . "</p>";
    }

    
    $stmt->close();
}

$sql = "SELECT id, username FROM new WHERE role = 'user'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Delete Users</title>
    <link rel="stylesheet" type="text/css" href="delete.css">
</head>
<body>
    <div class="container">
        <h1>Delete Users</h1>

        <?php if ($result->num_rows > 0) { ?>
            <table>
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr>
                <?php while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td>
                        <form method="post" onsubmit="return confirm('Are you sure you want to delete this user?');">
                            <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                            <input type="submit" value="Delete">
                        </form>
                    </td>
                </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <p>No users found.</p>
        <?php } ?>

        <?php
        $conn->close();
        ?>
    </div>
</body>
</html>
