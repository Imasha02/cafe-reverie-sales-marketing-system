<?php
$servername = "localhost";
$username = "imasha";         
$password = "imasha123";    
$dbname = "cafe";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
