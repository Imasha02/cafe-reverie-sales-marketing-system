<?php
session_start();
include('db.php');


 if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
} 


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $user_id = $_SESSION['user_id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']); // Sanitize comment input

    $query = "INSERT INTO comments (user_id, comment, created_at) VALUES ('$user_id', '$comment', NOW())";
    if (mysqli_query($conn, $query)) {
        echo "Comment submitted successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete']) && $_SESSION['role'] == 'admin') {
    $comment_id = $_POST['comment_id'];
    $query = "DELETE FROM comments WHERE comment_id = '$comment_id'";
    if (mysqli_query($conn, $query)) {
        echo "Comment deleted successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

$query = "SELECT comments.*, new.username FROM comments JOIN new ON comments.user_id = new.id ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comment Section</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
        }
        textarea {
            width: 100%;
            height: 100px;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .comment {
            background-color: #f4f4f4;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .comment strong {
            display: block;
            margin-bottom: 5px;
        }
        .comment .timestamp {
            font-size: 0.9em;
            color: #666;
        }
        form {
            display: inline;
        }

    </style>
</head>
<body>
    <div class="container">


        <h1>Comment Section</h1>


        <form method="POST" action="">
            <textarea name="comment" placeholder="Enter your comment..." required></textarea><br>
            <button type="submit">Submit Comment</button>
        </form>

        <h2>All Comments</h2>

        <!-- Display Comments -->
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="comment">
                <strong><?php echo $row['username']; ?></strong>
                <p><?php echo htmlspecialchars($row['comment']); ?></p>
                <span class="timestamp"><?php echo date('F j, Y, g:i a', strtotime($row['created_at'])); ?></span>

                <!--  delete btn for admins -->
                <?php if ($_SESSION['role'] == 'admin') { ?>
                    <form method="POST" action="">
                        <input type="hidden" name="comment_id" value="<?php echo $row['comment_id']; ?>">
                        <button style="background:red" type="submit" name="delete">Delete</button>
                    </form>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

</body>
</html>
