<?php
session_start();

$servername = "localhost";
$username = "imasha";
$password = "imasha123";     
$dbname = "cafe";   

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_msg = '';


if($_SERVER['REQUEST_METHOD'] == 'POST') 
$user = $_POST['username'];
$pass = $_POST['password'];
$role = $_POST['role'];






$sql = "SELECT * FROM new WHERE username = '$user';";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    
    $row = $result->fetch_assoc();
    
    if($pass == $row['password'] && $role == $row['role']){
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['user_id'] = $row['id'];
        if ($row['role'] == 'admin') {
                    header("Location: admin_dashboard.php");
                } else {
                    header("Location: user_dashboard.php");
                }
                exit();

    }
    else{
        echo "Invalid login info!";
    }
} else {
        echo "No user found with that username!";
}



$stmt->close();
$conn->close();


?> 
