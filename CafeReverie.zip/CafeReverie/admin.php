<?php
session_start();
include('db_connection.php');


function updateProductStock($productId, $quantity, $transactionType) {
    global $conn;

    if ($transactionType == 'add') {
        $query = "UPDATE products SET stock = stock + ? WHERE product_id = ?";
    } else if ($transactionType == 'remove') {
        $query = "UPDATE products SET stock = stock - ? WHERE product_id = ?";
    } else {
        echo "Invalid transaction type!";
        return;
    }

    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $quantity, $productId);
    $stmt->execute();
    $stmt->close();

    $query = "INSERT INTO inventory_transactions (product_id, transaction_type, quantity) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isi", $productId, $transactionType, $quantity);
    $stmt->execute();
    $stmt->close();

   echo  "<p style= 'color: white;'> Stock updated successfully! </p>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_stock'])) {
    $productId = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $transactionType = $_POST['transaction_type'];

    updateProductStock($productId, $quantity, $transactionType);
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<h1> Time to Tweak the Menu !</h1>

<h2>Update Food Quantity</h2>
<form method="post" action="">
    <label for="product_id">Product ID:</label>
    <select name ="product_id">
                 	 <option selected> p01</option> 
                	 <option> p02</option> 
                	 <option> p03</option> 
                	 <option> p04</option> 
			 <option> p05</option>
                         <option> p06</option> 
                	 <option> p07</option> 
                	 <option> p08</option> 
                	 <option> p09</option> 
			 <option> p10</option>
                         <option> p11</option> 
                	 <option> p12</option> 
                	 <option> p13</option> 
                	 <option> p14</option> 
			 <option> p15</option>
                         <option> p16</option> 
                	 <option> p17</option> 
                	 <option> p18</option> 
                	 <option> p19</option> 
			 <option> p20</option>
                 </select>
    
    <label for="quantity">Quantity:</label>
    <input type="number" id="quantity" name="quantity" step="1" min="1" max="100" required>
    
    <label for="transaction_type">Transaction Type:</label>
    <select id="transaction_type" name="transaction_type" required>
        <option value="add">Add Stock</option>
        <option value="remove">Remove Stock</option>
    </select>
    
    <input type="submit" name="update_stock" value="Update Stock">
    
    <p><a href="admin_dashboard.php" style="color: #fcb549; text-decoration: none;">Back to Dashboard</a></p>


</form>


</body>
</html>